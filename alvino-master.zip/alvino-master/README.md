APPS REQUIRED :
- TERMUX
- GOJEK

*WAJIB NOMOR BARU atau NOMOR YANG BELUM TERDAFTAR GOJEK*

Step By Step Command Line On Termux :
1. pkg install php
2. pkg install curl
3. pkg install git
4. git clone https://github.com/sibirubah/gojekin
5. cd gojekin
6. php gojek.php
7. masukin nomor hp
8. masukin kode verifikasi(OTP)
9. pilih kode voucher
10. repeat(ulangi seperti biasa)
